package com.rocketmonny.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class MainActivity extends Activity {
    private WebView webView;
    private RewardedAd rewardedAd;
    private InterstitialAd interstitialAd;
    private int completedRounds = 0;
    private boolean adsInitialized = false;

    // Keep test ads enabled while developing/testing. Set false only for a properly
    // tested release build. Never click your own live ads.
    private static final boolean USE_TEST_ADS = true;
    private static final String REAL_REWARDED_ID = "ca-app-pub-8156315546303920/9865151147";
    private static final String REAL_INTERSTITIAL_ID = "ca-app-pub-8156315546303920/6572998738";
    private static final String TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917";
    private static final String TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";

    private String rewardedUnitId() { return USE_TEST_ADS ? TEST_REWARDED_ID : REAL_REWARDED_ID; }
    private String interstitialUnitId() { return USE_TEST_ADS ? TEST_INTERSTITIAL_ID : REAL_INTERSTITIAL_ID; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF07111F);
        getWindow().setNavigationBarColor(0xFF07111F);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF07111F);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setAllowFileAccessFromFileURLs(false);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(false);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.addJavascriptInterface(new AdsBridge(), "AndroidAds");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        WebView.setWebContentsDebuggingEnabled(false);
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        MobileAds.initialize(this, initializationStatus -> {
            adsInitialized = true;
            loadRewardedAd();
            loadInterstitialAd();
        });
    }

    private void loadRewardedAd() {
        if (!adsInitialized) return;
        RewardedAd.load(this, rewardedUnitId(), new AdRequest.Builder().build(),
            new RewardedAdLoadCallback() {
                @Override public void onAdLoaded(RewardedAd ad) { rewardedAd = ad; }
                @Override public void onAdFailedToLoad(LoadAdError error) { rewardedAd = null; }
            });
    }

    private void loadInterstitialAd() {
        if (!adsInitialized) return;
        InterstitialAd.load(this, interstitialUnitId(), new AdRequest.Builder().build(),
            new InterstitialAdLoadCallback() {
                @Override public void onAdLoaded(InterstitialAd ad) { interstitialAd = ad; }
                @Override public void onAdFailedToLoad(LoadAdError error) { interstitialAd = null; }
            });
    }

    private void js(String script) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(script, null);
        });
    }

    private class AdsBridge {
        @JavascriptInterface
        public void showRewardedAd() {
            runOnUiThread(() -> {
                if (rewardedAd == null) {
                    js("window.onRewardedAdUnavailable && window.onRewardedAdUnavailable()");
                    loadRewardedAd();
                    return;
                }
                RewardedAd ad = rewardedAd;
                rewardedAd = null;
                ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() { loadRewardedAd(); }
                    @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError error) {
                        loadRewardedAd();
                        js("window.onRewardedAdUnavailable && window.onRewardedAdUnavailable()");
                    }
                });
                ad.show(MainActivity.this, rewardItem ->
                    js("window.onRewardEarned && window.onRewardEarned()"));
            });
        }

        @JavascriptInterface
        public void onRoundFinished() {
            runOnUiThread(() -> {
                completedRounds++;
                if (completedRounds >= 3) {
                    completedRounds = 0;
                    showInterstitialIfReady();
                }
            });
        }
    }

    private void showInterstitialIfReady() {
        if (interstitialAd == null) {
            loadInterstitialAd();
            return; // Skip this break if an ad is not ready; never block gameplay.
        }
        InterstitialAd ad = interstitialAd;
        interstitialAd = null;
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() { loadInterstitialAd(); }
            @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError error) {
                loadInterstitialAd();
            }
        });
        ad.show(this);
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidAds");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
