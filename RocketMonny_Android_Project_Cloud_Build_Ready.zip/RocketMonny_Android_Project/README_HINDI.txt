ROCKET MONNY — ANDROID PROJECT

Is ZIP mein Android WebView app ka source code aur game HTML shamil hai.

PROJECT SETUP
- Package ID: com.rocketmonny.app
- Minimum Android: 7.0 (API 24)
- Compile SDK / Target SDK: 36
- Android Gradle Plugin: 8.13.2
- Google Mobile Ads SDK: 25.5.0

SOURCE FEATURES
- Local HTML game Android WebView mein load hota hai.
- AdMob App ID manifest mein configured hai.
- Rewarded ad success callback par 100 virtual coins milte hain (maximum 5 per day).
- Har 3 completed rounds par interstitial ad ka attempt hota hai. Agar ad ready na ho to gameplay block nahi hota aur woh opportunity skip hoti hai.
- Development ke liye Google ke official test ad unit IDs enabled hain. Real ad IDs source mein configured hain, lekin release build se pehle proper testing aur policy review zaroori hai.
- Launcher icon aur WebView file-origin restrictions add ki gayi hain.

IMPORTANT LIMITATIONS
- Yeh source project hai, APK/AAB nahi.
- Is environment mein Android SDK, Gradle executable aur Gradle Wrapper JAR available nahi the; isliye APK/AAB compile aur device testing nahi hui.
- Browser preview native Android ads nahi chala sakta; ads Android app build mein hi test honge.
- Coins virtual/demo hain. UPI withdrawal screen sirf local demo request record karti hai; real payment, wallet ya payout system nahi hai.
- Profile details local device storage mein hain; secure OTP login/server account nahi hai.

BUILD KARNE KE LIYE
1. Android Studio install karein.
2. Is ZIP ko extract karke RocketMonny_Android_Project folder Android Studio mein open karein.
3. Android SDK Platform 36 install karein aur Gradle sync hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) se test APK banayein.
5. Play Store ke liye Build > Generate Signed Bundle / APK > Android App Bundle chunein.
6. Apni signing key aur password ko private aur safe rakhein.

Play Store se pehle privacy policy, Data safety form, app icon/screenshots, ad disclosures, content rating aur Google Play policy compliance complete karna zaroori hai.


BUILD SETUP UPDATE
- Gradle 8.13 distribution configuration file add ki gayi hai: gradle/wrapper/gradle-wrapper.properties.
- SDK path example aur .gitignore add kiye gaye hain.
- Android SDK ko ZIP mein include nahi kiya ja sakta; use Android Studio SDK Manager se computer par install karna hoga.
- Is environment mein internet access na hone ke karan official gradle-wrapper.jar / gradlew scripts download nahi ho sake. Isliye wrapper abhi complete nahi hai.
- Details: BUILD_SETUP_HINDI.txt


Cloud build workflow: .github/workflows/android-build.yml
Build instructions: BUILD_SETUP_HINDI.txt
